module BakerBob
  VERSION = '0.0.1'
  AGENT_ID = "bakerbob/#{VERSION}"
end
