This ${content_type} has received a ${vote_weight_percent} % ${vote_type} from @${account_name} thanks to: @${from}.
